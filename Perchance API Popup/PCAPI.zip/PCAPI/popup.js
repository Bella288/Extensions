document.addEventListener('DOMContentLoaded', function() {
  const downloadButton = document.getElementById('downloadButton');
  const messageDiv = document.getElementById('message');
  const nameInput = document.getElementById('generatorName');

  // Load stored generator name
  chrome.storage.local.get('generatorName', function(data) {
    if (data.generatorName) {
      nameInput.value = data.generatorName;
    }
  });

  downloadButton.addEventListener('click', function() {
    messageDiv.textContent = "Downloading..."; // Update message
    const generatorName = nameInput.value;
    const url = `https://perchance.org/api/downloadGenerator?generatorName=${generatorName}`;

    // Basic name validation
    if (!generatorName) {
      messageDiv.textContent = "Error: Please enter a generator name.";
      alert('Please enter a Perchance generator name.');
      return;
    }

    // Save the generator name
    chrome.storage.local.set({ generatorName: generatorName }, function() {
      // Optional:  You could add a message here to confirm the name was saved.
      console.log('Generator name stored: ' + generatorName);
    });

    fetch(url)
      .then(response => {
        if (!response.ok) {
          throw new Error(`HTTP error! status: ${response.status}`);
        }
        return response.blob();
      })
      .then(blob => {
        // Create a temporary URL for the Blob
        const url = URL.createObjectURL(blob);

        // Use chrome.downloads API
        chrome.downloads.download({
            url: url,
            filename: `${generatorName}.txt`, // Use generator name in filename
            saveAs: true // Show the "Save As" dialog
          }, function(downloadId) {
            if (downloadId) {
              messageDiv.textContent = "Download started!";
            } else {
              messageDiv.textContent = "Download failed.";
            }
             // Clean up the temporary URL
             URL.revokeObjectURL(url);
          });
      })
      .catch(error => {
        console.error('Error:', error);
        messageDiv.textContent = "Error: " + error.message;
        alert('Failed to retrieve or download data. Check the console for errors.');
      });
  });
});
