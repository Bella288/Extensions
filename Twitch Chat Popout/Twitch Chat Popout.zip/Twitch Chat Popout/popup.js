document.addEventListener('DOMContentLoaded', function() {
  const streamerInput = document.getElementById('streamerInput');
  const openChatButton = document.getElementById('openChatButton');

  openChatButton.addEventListener('click', function() {
    const streamerUsername = streamerInput.value.trim();
    if (streamerUsername) {
      const popoutUrl = `https://www.twitch.tv/popout/${streamerUsername}/chat`;

      // Get current window dimensions for positioning (optional, but good UX)
      chrome.windows.getCurrent(function(currentWindow) {
        const width = 400; // Desired width of the pop-up window
        const height = 600; // Desired height of the pop-up window
        const left = currentWindow.left + (currentWindow.width / 2) - (width / 2);
        const top = currentWindow.top + (currentWindow.height / 2) - (height / 2);

        chrome.windows.create({
          url: popoutUrl,
          type: 'popup', // This is key to make it a smaller, title-bar-less window
          width: width,
          height: height,
          left: Math.round(left),
          top: Math.round(top)
        }, function(newWindow) {
          // You can do something with the new window's ID here if needed
          // For instance, focus it: chrome.windows.update(newWindow.id, { focused: true });
        });
      });

    } else {
      alert('Please enter a streamer username.');
    }
  });
});